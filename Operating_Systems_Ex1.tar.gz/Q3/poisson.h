#ifndef POISSON_H
#define POISSON_H

long double factorial(int n);
long double poisson(long double lambda, int k);

#endif /* POISSON_H */