#ifndef PHONEBOOK_H
#define PHONEBOOK_H

void add2PB(const char* name, const char* phoneNumber);
void findPhone(const char* name);
void printPhoneBook();
void printContact(const char* name);

#endif // PHONEBOOK_H
